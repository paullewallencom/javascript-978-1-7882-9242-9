import Rx from 'rxjs/Rx';

const appContainer = document.querySelector( '.js-app' );

