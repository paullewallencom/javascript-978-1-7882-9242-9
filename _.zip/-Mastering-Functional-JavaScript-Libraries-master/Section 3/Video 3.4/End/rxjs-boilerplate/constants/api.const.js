

export const API_TOKEN = 'PASTE YOUR TOKEN HERE';

